﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DataService dataService = new DataService();
            List<Book> books = dataService.LoadBooks();
            int nextId = books.Count > 0 ? books.Max(b => b.Id) + 1 : 1;

            while (true)
            {
                Console.Clear();
                Console.WriteLine("📚 Kütüphane Yönetim Sistemi");
                Console.WriteLine("-----------------------------");
                Console.WriteLine("1 - Kitap Ekle");
                Console.WriteLine("2 - Kitapları Listele");
                Console.WriteLine("3 - Kitap Ara");
                Console.WriteLine("4 - Kitap Ödünç Al");
                Console.WriteLine("5 - Kitap İade Et");
                Console.WriteLine("6 - Kitap Sil");
                Console.WriteLine("0 - Çıkış");
                Console.Write("Seçiminiz: ");
                string choice = Console.ReadLine() ?? "";

                switch (choice)
                {
                    case "1":
                        AddBook(books, ref nextId, dataService);
                        break;

                    case "2":
                        ListBooks(books);
                        break;

                    case "3":
                        SearchBook(books);
                        break;

                    case "4":
                        BorrowBook(books, dataService);
                        break;

                    case "5":
                        ReturnBook(books, dataService);
                        break;

                    case "6":
                        DeleteBook(books, dataService);
                        break;

                    case "0":
                        dataService.SaveBooks(books);
                        return;

                    default:
                        Console.WriteLine("Geçersiz seçim!");
                        break;
                }

                Console.WriteLine("\nDevam etmek için bir tuşa bas...");
                Console.ReadKey();



            }
        }
        static void AddBook(List<Book> books, ref int nextId, DataService dataService)
        {
            Console.Write("Kitap Adı: ");
            string title = Console.ReadLine() ?? "";
            Console.Write("Yazar: ");
            string author = Console.ReadLine() ?? "";

            books.Add(new Book { Id = nextId++, Title = title, Author = author });
            dataService.SaveBooks(books);
            Console.WriteLine("✅ Kitap eklendi!");
        }

        static void ListBooks(List<Book> books)
        {
            Console.WriteLine("\n📖 Kitaplar:");
            foreach (var book in books)
            {
                Console.WriteLine(book);
            }
        }

        static void SearchBook(List<Book> books)
        {
            Console.Write("Aranacak kelime (ad/yazar): ");
            string keyword = Console.ReadLine()?.ToLower() ?? "";

            var results = books.Where(b => b.Title.ToLower().Contains(keyword) || b.Author.ToLower().Contains(keyword)).ToList();

            if (results.Count > 0)
            {
                Console.WriteLine("\n🔍 Arama Sonuçları:");
                foreach (var book in results)
                    Console.WriteLine(book);
            }
            else
            {
                Console.WriteLine("Hiç sonuç bulunamadı.");
            }
        }

        static void BorrowBook(List<Book> books, DataService dataService)
        {
            Console.Write("Ödünç alınacak kitap ID: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                var book = books.FirstOrDefault(b => b.Id == id);
                if (book != null && !book.IsBorrowed)
                {
                    book.IsBorrowed = true;
                    dataService.SaveBooks(books);
                    Console.WriteLine("📕 Kitap ödünç alındı!");
                }
                else
                {
                    Console.WriteLine("Kitap bulunamadı veya zaten ödünç alınmış.");
                }
            }
        }

        static void ReturnBook(List<Book> books, DataService dataService)
        {
            Console.Write("İade edilecek kitap ID: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                var book = books.FirstOrDefault(b => b.Id == id);
                if (book != null && book.IsBorrowed)
                {
                    book.IsBorrowed = false;
                    dataService.SaveBooks(books);
                    Console.WriteLine("📗 Kitap iade edildi!");
                }
                else
                {
                    Console.WriteLine("Kitap bulunamadı veya zaten iade edilmiş.");
                }
            }
        }

        static void DeleteBook(List<Book> books, DataService dataService)
        {
            Console.Write("Silinecek kitap ID: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                var book = books.FirstOrDefault(b => b.Id == id);
                if (book != null)
                {
                    books.Remove(book);
                    dataService.SaveBooks(books);
                    Console.WriteLine("🗑️ Kitap silindi!");
                }
                else
                {
                    Console.WriteLine("Kitap bulunamadı.");
                }
            }
        }
    }
}
